let timer = 30;
let countdown;

function startTimer() {
    countdown = setInterval(() => {
        document.getElementById("timer").innerText = timer;

        if (timer === 0) {
            dropBall();
            timer = 30; 
        }

        timer--;
    }, 1000);
}

function dropBall() {
    let winningBox = Math.floor(Math.random() * 4) + 1;
    let ball = document.getElementById("ball");

    let positions = { 1: [20, 20], 2: [20, 230], 3: [230, 20], 4: [230, 230] };
    ball.style.top = positions[winningBox][0] + "px";
    ball.style.left = positions[winningBox][1] + "px";
}

window.onload = startTimer;
